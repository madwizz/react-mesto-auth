import React from "react";

function Footer() {
  return (
    <footer className="footer">
      &copy; {new Date().getFullYear()} Mesto Russia
    </footer>
  );
}

export default Footer;
