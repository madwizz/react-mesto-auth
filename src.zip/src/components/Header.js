import React from "react";
import logoPath from "../images/header-logo.svg";
import { Routes, Route, Link } from "react-router-dom";

function Header({ email, onSignOut }) {
  return (
    <header className="header">
      <img
        className="header__logo"
        src={logoPath}
        alt="логотип-сайта-место-россия"
      />
      <div className="header__container">
        <p className="header__email">{email}</p>
        <Routes>
          <Route
            path="/*"
            element={
              <Link to="/sign-in" onClick={onSignOut} className="header__link">
                Выйти
              </Link>
            }
          />
          <Route
            path="/sign-in"
            element={
              <Link to="/sign-up" className="header__link">
                Регистрация
              </Link>
            }
          />
          <Route
            path="/sign-up"
            element={
              <Link to="/sign-in" className="header__link">
                Войти
              </Link>
            }
          />
        </Routes>
      </div>
    </header>
  );
}

export default Header;
